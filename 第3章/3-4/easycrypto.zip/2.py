import hashlib
import os
s=os.urandom(8)
print s[0:5].encode('hex')
print hashlib.sha256(s).hexdigest()
#0d273d5891
#1226bf22ea059fb56ac176ae79ae89a09c5433213a2f8c3d6ebd60bb0445e72f
#password:s.encode('hex')